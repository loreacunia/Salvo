Vue.component('alumno', {
    props: ['nombre', 'apellido'],
    template: `
      <div>
        <h3>{{ 'Nombre: ' + nombre }}</h3>  
        <h3>{{ 'Apellido: ' + apellido }}</h3>
        <hr>
      </div>
    `,
})

var app = new Vue({
    el: '#app',
    data: {
        alumnos: [{
            nombre: "Ahmad",
            apellido: "Saed"
        },
        {
            nombre: "Maria",
            apellido: "Lorena"
        }]
    }
})